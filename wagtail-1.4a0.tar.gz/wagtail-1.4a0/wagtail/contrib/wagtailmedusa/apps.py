from django.apps import AppConfig


class WagtailMedusaAppConfig(AppConfig):
    name = 'wagtail.contrib.wagtailmedusa'
    label = 'wagtailmedusa'
    verbose_name = "Wagtail medusa"
