default_app_config = 'wagtail.contrib.wagtailmedusa.apps.WagtailMedusaAppConfig'
