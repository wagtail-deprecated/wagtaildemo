class RemovedInWagtail15Warning(DeprecationWarning):
    pass


removed_in_next_version_warning = RemovedInWagtail15Warning


class RemovedInWagtail16Warning(PendingDeprecationWarning):
    pass
