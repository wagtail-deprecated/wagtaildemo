# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations


class Migration(migrations.Migration):

    dependencies = [
        ('tests', '0007_auto_20150819_0614'),
        ('tests', '0007_singleeventpage'),
    ]

    operations = [
    ]
