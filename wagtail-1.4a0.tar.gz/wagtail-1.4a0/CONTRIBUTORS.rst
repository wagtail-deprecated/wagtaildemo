Authors
================

* Matthew Westcott (Torchbox) twitter: @gasmanic
* David Cranwell (Torchbox) twitter: @davecranwell
* Karl Hobley (Torchbox) twitter: @kaedroho
* Tim Heap (Takeflight)

Contributors
============

* Helen Chapman helen.chapman@torchbox.com
* Balazs Endresz balazs.endresz@torchbox.com
* Neal Todd neal.todd@torchbox.com
* Paul Hallett (twilio) hello@phalt.co
* Tom Dyson
* Serafeim Papastefanos
* Łukasz Bołdys
* peterarenot
* Levi Gross
* Delgermurun Purevkhuu
* Lewis Cowper
* Stephen Newey
* Ryan Foster
* v1kku
* Miguel Vieira
* Ben Emery
* David Smith
* Ben Margolis
* Tom Talbot
* Jeffrey Hearn
* Robert Clark
* Nathan Brizendine
* thenewguy
* John-Scott Atlakson
* Eric Drechsel
* Alejandro Giacometti
* Robert Rollins
* linibou
* Timo Rieber
* Jerel Unruh
* georgewhewell
* Frank Wiles
* Sebastian Spiegel
* Alejandro Varas
* Martin Sanders
* Benoît Bar
* Claudemiro
* Tiago Henriques
* Arne Schauf
* Jordi Joan
* Damian Moore
* signalkraft
* Mac Chapman
* Brett Grace
* Nar Chhantyal
* Michael Fillier
* Mitchel Cabuloy
* Piet Delport
* Tom Christie
* Michael van Tellingen
* Scot Hacker
* Kyungil Choi
* Joss Ingram
* Christoph Lipp
* Michael Cordover
* Timothy Allen
* Rob Shelton
* Anurag Sharma
* Maximilian Stauss
* Salvador Faria
* Alex Gleason
* Ryan Pineo
* Petr Vacha
* Josh Barr
* Sævar Öfjörð Magnússon
* Ashia Zawaduk
* Denis Voskvitsov
* Kyle Stratis
* Sergey Nikitin
* John Draper
* Rich Brennan
* Alex Bridge
* Tamriel
* LKozlowski
* Matthew Downey
* Maris Serzans
* Shu Ishida
* Ben Kerle
* Christian Peters
* Adon Metcalfe
* rayrayndwiga
* Rich Atkinson
* jnns
* Eugene MechanisM
* benjaoming
* Alexander Bogushov
* Aarni Koskela
* alexpilot11
* Peter Quade
* Josh Hurd
* Matt Fozard
* Chris Rogers
* Josh Schneier
* Mikalai Radchuk
* Charlie Choiniere
* Nigel Fletton


Translators
===========

* Arabic: Roger Allen, Ahmad Kiswani, Mohamed Mayla
* Basque: Unai Zalakain
* Bulgarian: Lyuboslav Petrov
* Catalan: Antoni Aloy, David Llop
* Chinese: hanfeng, Lihan Li, Leway Colin
* Chinese (China): hanfeng, Daniel Hwang, Jian Li, Feng Wang
* Chinese (Taiwan): Lihan Li
* Croatian (Croatia): Luka Matijević
* Czech: Ivan Pomykacz, Jiri Stepanek, Marek Turnovec
* Dutch: benny_AT_it_digin.com, Bram, Brecht Dervaux, Huib Keemink, Thijs Kramer, Samuel Leeuwenburg, mahulst, Michael van Tellingen, Arne Turpyn
* Dutch (Netherlands): Bram, Franklin Kingma, Maarten Kling, Thijs Kramer
* Finnish: Eetu Häivälä, Aarni Koskela, Glen Somerville
* French: Adrien, Timothy Allen, Sebastien Andrivet, Bertrand Bordage, André Bouatchidzé, Tom Dyson, Pierre Marfoure, nahuel
* Galician: fooflare
* Georgian: André Bouatchidzé
* German: Ettore Atalan, Patrick Craston, Florian, Henrik Kröger, Tammo van Lessen, Martin Löhle, Wasilis Mandratzis-Walz, Daniel Manser, m0rph3u5, Max Pfeiffer, Herbert Poul, Karl Sander, Johannes Spielmann, Jannis Vajen, Matthew Westcott
* Greek: Jim Dal, dotoree, Wasilis Mandratzis-Walz, NeotheOne, Serafeim Papastefanos
* Hebrew (Israel): bjesus, Lior Abazon
* Hungarian: Laszlo Molnar
* Icelandic: Arnar Tumi Þorsteinsson, Sævar Öfjörð Magnússon
* Italian: Edd Baldry, Claudio Bantaloukas, Giacomo Ghizzani, Alessio Di Stasio, Andrea Tagliazucchi
* Japanese: Sangmin Ahn, Shu Ishida, Daigo Shitara, takuan_osho
* Korean: Kyungil Choi, Ji Han Chung
* Latvian: Maris Serzans
* Mongolian: Delgermurun Purevkhuu
* Norwegian Bokmål: Eirik Krogstad, Robin Skahjem-Eriksen
* Polish: Mateusz, utek
* Portuguese (Brazil): Claudemiro Alves Feitosa Neto, Gladson Brito, Thiago Cangussu, Gilson Filho, João Luiz Lorencetti, Douglas Miranda
* Portuguese (Portugal): Gladson Brito, Thiago Cangussu, Tiago Henriques, Jose Lourenco, Nuno Matos, Douglas Miranda, Manuela Silva
* Romanian: Dan Braghis
* Russian: ajk, Daniil, HNKNTA, Sergiy Khalymon, Sergey Komarov, Eugene MechanisM
* Spanish: José Alaguna, Mauricio Baeza, Daniel Chimeno, fonso, fooflare, Joaquín Tita, Unai Zalakain
* Slovak (Slovakia): dellax
* Swedish: Ludwig Kjellström, Thomas Kunambi, Hannes Lohmander
* Swedish (Sweden): Thomas Kunambi
* Turkish: Cihad Gündoǧdu
* Turkish (Turkey): José Alaguna, Ragıp Ünal
* Vietnamese: Luan Nguyen
